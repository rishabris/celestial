import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import HomePage from './HomePage';
import ProfilePage from './ProfilePage';
import UploadModal from './UploadModal';

type PageType = 'home' | 'profile' | 'explore' | 'notifications' | 'messages' | 'bookmarks' | 'settings';

const AppLayout = () => {
  const { logout } = useUser();
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadType, setUploadType] = useState<'post' | 'bit'>('post');

  const handleOpenUpload = (type: 'post' | 'bit') => {
    setUploadType(type);
    setUploadModalOpen(true);
  };

  const handleNavigation = (page: string) => {
    setCurrentPage(page as PageType);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'profile':
        return <ProfilePage onNavigateBack={() => setCurrentPage('home')} />;
      case 'home':
      default:
        return (
          <HomePage 
            onLogout={logout}
            onNavigate={handleNavigation}
            onOpenUpload={handleOpenUpload}
          />
        );
    }
  };

  return (
    <>
      {renderCurrentPage()}
      <UploadModal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        type={uploadType}
      />
    </>
  );
};

export default AppLayout;