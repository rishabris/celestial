import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Post, Bit } from '@/types/user';

interface UserContextType {
  currentUser: User | null;
  users: User[];
  posts: Post[];
  bits: Bit[];
  login: (username: string, password: string) => Promise<boolean>;
  register: (userData: Omit<User, 'id' | 'joinedDate' | 'followers' | 'following' | 'verified'> & { password: string }) => Promise<boolean>;
  logout: () => void;
  createPost: (content: string, image?: string) => void;
  createBit: (bitData: Omit<Bit, 'id' | 'author' | 'createdAt' | 'views' | 'likes' | 'isLiked'>) => void;
  updateProfile: (userData: Partial<User>) => void;
  checkUsernameAvailable: (username: string) => boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

const generateId = () => Math.random().toString(36).substr(2, 9);

const mockUsers: User[] = [
  {
    id: '1',
    username: 'lunacosmic',
    email: 'luna@celestial.com',
    displayName: 'Luna Rodriguez',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b2e29c64?w=150',
    bio: 'Exploring the cosmos, one star at a time ✨',
    website: 'lunacosmic.dev',
    location: 'San Francisco, CA',
    joinedDate: '2023-01-15',
    followers: 1247,
    following: 89,
    verified: true
  },
  {
    id: '2',
    username: 'alexstars',
    email: 'alex@celestial.com',
    displayName: 'Alex Stargazer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    bio: 'Developer by day, astronomer by night 🌟',
    location: 'New York, NY',
    joinedDate: '2023-03-20',
    followers: 856,
    following: 234,
    verified: false
  }
];

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [posts, setPosts] = useState<Post[]>([]);
  const [bits, setBits] = useState<Bit[]>([]);

  useEffect(() => {
    // Load from localStorage on mount
    const savedUser = localStorage.getItem('celestial_current_user');
    const savedUsers = localStorage.getItem('celestial_users');
    const savedPosts = localStorage.getItem('celestial_posts');
    const savedBits = localStorage.getItem('celestial_bits');

    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    }
    if (savedPosts) {
      setPosts(JSON.parse(savedPosts));
    }
    if (savedBits) {
      setBits(JSON.parse(savedBits));
    }
  }, []);

  useEffect(() => {
    // Save to localStorage whenever state changes
    localStorage.setItem('celestial_users', JSON.stringify(users));
    localStorage.setItem('celestial_posts', JSON.stringify(posts));
    localStorage.setItem('celestial_bits', JSON.stringify(bits));
    if (currentUser) {
      localStorage.setItem('celestial_current_user', JSON.stringify(currentUser));
    }
  }, [users, posts, bits, currentUser]);

  const checkUsernameAvailable = (username: string): boolean => {
    return !users.some(user => user.username.toLowerCase() === username.toLowerCase());
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const user = users.find(u => u.username === username || u.email === username);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const register = async (userData: Omit<User, 'id' | 'joinedDate' | 'followers' | 'following' | 'verified'> & { password: string }): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (!checkUsernameAvailable(userData.username)) {
      return false;
    }

    const newUser: User = {
      ...userData,
      id: generateId(),
      joinedDate: new Date().toISOString().split('T')[0],
      followers: 0,
      following: 0,
      verified: false
    };

    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('celestial_current_user');
  };

  const createPost = (content: string, image?: string) => {
    if (!currentUser) return;

    const newPost: Post = {
      id: generateId(),
      author: currentUser,
      content,
      image,
      createdAt: new Date().toISOString(),
      likes: 0,
      reposts: 0,
      comments: 0,
      isLiked: false,
      isReposted: false
    };

    setPosts(prev => [newPost, ...prev]);
  };

  const createBit = (bitData: Omit<Bit, 'id' | 'author' | 'createdAt' | 'views' | 'likes' | 'isLiked'>) => {
    if (!currentUser) return;

    const newBit: Bit = {
      ...bitData,
      id: generateId(),
      author: currentUser,
      createdAt: new Date().toISOString(),
      views: 0,
      likes: 0,
      isLiked: false
    };

    setBits(prev => [newBit, ...prev]);
  };

  const updateProfile = (userData: Partial<User>) => {
    if (!currentUser) return;

    const updatedUser = { ...currentUser, ...userData };
    setCurrentUser(updatedUser);
    setUsers(prev => prev.map(user => user.id === currentUser.id ? updatedUser : user));
  };

  return (
    <UserContext.Provider value={{
      currentUser,
      users,
      posts,
      bits,
      login,
      register,
      logout,
      createPost,
      createBit,
      updateProfile,
      checkUsernameAvailable
    }}>
      {children}
    </UserContext.Provider>
  );
};